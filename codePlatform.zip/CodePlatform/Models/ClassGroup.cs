﻿namespace CodePlatform.Models
{
    public class ClassGroup
    {
        public string Name { get; set; }
        public string Direction { get; set; }
        public int CourseNumber { get; set; }

        public ClassGroup(string name, string direction, int courseNumber)
        {
            Name = name;
            Direction = direction;
            CourseNumber = courseNumber;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
