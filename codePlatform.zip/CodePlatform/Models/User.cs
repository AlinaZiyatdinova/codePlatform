﻿using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace CodePlatform.Models
{
    public class User
    {
        public string Login { get; set; }
        public string Fullname { get; set; }
        public string HashedPassword { get; set; }
        public ClassGroup ClassGroup { get; set; }
        public Organization Organization {get;set; }


        public User (string login, string fullname, string password, ClassGroup group, Organization organization)
        {

            Login = login;
            HashedPassword = password;
            Fullname = fullname;
            ClassGroup = group;
            Organization = organization;
        }
    }
}
