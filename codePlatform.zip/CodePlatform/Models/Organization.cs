﻿namespace CodePlatform.Models
{
    public class Organization
    {
        public string Name { get; set; }
        public Organization(string name)
        {
            Name = name;
        }
    }
}
