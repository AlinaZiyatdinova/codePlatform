using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CodePlatform.Pages
{
    public class LogoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
