using CodePlatform.Models;
using CodePlatform.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CodePlatform.Pages
{
    public class RegistartionModel : PageModel
    {
        private readonly UserService _userService;
        public RegistartionModel(UserService userService)
        {
            _userService = userService;
        }

        [BindProperty] public string Login { get; set; }
        [BindProperty] public string Password { get; set; }
        [BindProperty] public string FullName { get; set; }
        [BindProperty] public string GroupName { get; set; }
        [BindProperty] public int CourseNumber { get; set; }
        [BindProperty] public string OrganizationName { get; set; }

        public List<string> Groups { get; set; } = new() { "������ 1", "������ 2" };
        public List<string> Organizations { get; set; } = new() { "������� 1", "������� 2" };
        public string Message { get;set; }
        public IActionResult OnPost()
        {
            return Page();
        }

    }
}
