using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CodePlatform.Pages
{
    public class UserStatisticModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
