﻿using CodePlatform.Models;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace CodePlatform.Services
{
    public class UserService
    {
        private static List<User> _users = new();
        private static List<Organization> _organizations = new()
        {
            new Organization("Колледж 1"),
            new Organization("Колледж 2")
        };
        private static Dictionary<string, List<ClassGroup>> _orgGroups = new()
        {
            { "Колледж 1", new List<ClassGroup>
                {
                    new ClassGroup("Группа 1", "Информатика", 1),
                    new ClassGroup("Группа 2", "Дизайн", 2)
                }
            },
             { "Колледж 2", new List<ClassGroup>
                {
                    new ClassGroup("Группа 12", "Физика", 4),
                    new ClassGroup("Группа 23", "Математика", 2)
                }
            }
        };
        public bool Register(string login, string fullname, string password, string organizationName, string groupName)
        {
            if(_users.Any(u=>u.Login == login))
            {
                return false;
            }
            Organization organization = _organizations.FirstOrDefault(o => o.Name == organizationName);
            ClassGroup group = _orgGroups[organizationName].FirstOrDefault(g => g.Name == groupName);
            
            if(organization == null || group == null)
            {
                return false;
            }

            string hashedPassword = HashPassword(password);

            _users.Add(new User(login, fullname, hashedPassword, group, organization));
            return true;
        }

        public User Authenticate(string login, string password)
        {
            string hashedPassword = HashPassword(password);
            return _users.FirstOrDefault(u => u.Login == login && u.HashedPassword == hashedPassword);
        }

        private static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public List<Organization> GetOrganizations() => _organizations;
        public List<User> GetAllUsers() => _users;

        public List<ClassGroup> GetGroupsByOrganization(string organizationName)
        {
            return _orgGroups.ContainsKey(organizationName) ? _orgGroups[organizationName] : new List<ClassGroup>();
        }




    }
}
