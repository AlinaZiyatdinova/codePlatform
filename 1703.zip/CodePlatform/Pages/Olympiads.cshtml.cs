using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CodePlatform.Pages
{
    public class OlympiadsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
