﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace CodePlatform.Models
{
    public class User: IdentityUser
    {
        public string Fullname { get; set; }
        public ClassGroup ClassGroup { get; set; }
        public Organization Organization {get;set; }


    }
}
