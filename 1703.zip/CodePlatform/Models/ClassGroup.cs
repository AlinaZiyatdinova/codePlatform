﻿namespace CodePlatform.Models
{
    public class ClassGroup
    {
        public string Name { get; set; }
        public string Direction { get; set; }
        public int CourseNumber { get; set; }
        public int OrganizationId { get; set; }
        public Organization Organization { get; set; }

    }
}
