﻿namespace CodePlatform.Models
{
    public class Organization
    {
        public int Idd { get; set; }
        public string Name { get; set; }
        public List<ClassGroup> Groups { get; set; } = new();
    }
}
