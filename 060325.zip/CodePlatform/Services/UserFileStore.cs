﻿using CodePlatform.Interfaces;
using CodePlatform.Models;
using System.Text.Json;

namespace CodePlatform.Services
{
    public class UserFileStore: IUserFileStore
    {
        private readonly string _filePath = "user.json";
        private List<User> _users = new List<User>();

        public UserFileStore()
        {
            if (File.Exists(_filePath))
            {
                var json = File.ReadAllText(_filePath);
                _users = JsonSerializer.Deserialize<List<User>>(json) ?? new List<User>();
            }
            else
            {
                _users = new List<User>();
            }
        }
        private Task SaveShangesAsync()
        {
            var json = JsonSerializer.Serialize(_users, new JsonSerializerOptions
            {
                WriteIndented = true
            });
            File.WriteAllText(_filePath, json);
            return Task.CompletedTask;
        }
        public Task<User?> GetUserByLoginAsync(string login)
        {
            var user = _users.FirstOrDefault(u => u.Login.Equals(login, StringComparison.OrdinalIgnoreCase));
            return Task.FromResult(user);
        }

        public async Task<bool> AddUserAsync(User user)
        {
            if(_users.Any(u=>u.Login.Equals(user.Login, StringComparison.OrdinalIgnoreCase)))
            {
                return false;
            }
            _users.Add(user);
            await SaveShangesAsync();
            return true;
    
        }
        public Task<List<User>> GetAllUserAsync()
        {
            return Task.FromResult(_users.ToList());
        }
    }
}
