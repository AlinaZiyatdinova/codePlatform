using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CodePlatform.Pages.Shared
{
    public class MaterialsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
