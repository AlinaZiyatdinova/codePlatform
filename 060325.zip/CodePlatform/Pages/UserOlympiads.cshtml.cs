using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CodePlatform.Pages
{
    public class UserOlympiadsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
