using CodePlatform.Classes;
using CodePlatform.Interfaces;
using CodePlatform.Models;
using CodePlatform.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace CodePlatform.Pages
{
    public class RegistartionModel : PageModel
    {
        private readonly IUserFileStore _userStore;
        public RegistartionModel(IUserFileStore userStore)
        {
            _userStore = userStore;
        }

        [BindProperty]
        [Required(ErrorMessage = "������� �����")]
        [EmailAddress]
        public string Login { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "������� ���")]
        public string Fullname { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "������� �����")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        
        [BindProperty]
        [Required(ErrorMessage = "�������� �����������")]
        public string SelectedOrganizationName { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "�������� ������")]
        public string SelectedGroupName { get; set; }


        public List<Organization> Organizations { get; set; } = new();
        public List<ClassGroup> Groups { get; set; } = new();

        public void OnGet()
        {
            Organizations = StaticData.Organizations;
        }
        public async Task<IActionResult> OnPost()
        {
            if(!ModelState.IsValid)
            {
                OnGet();
                return Page();
            }

            OnGet();

            var org = Organizations.Find(o => o.Name == SelectedOrganizationName);


            ClassGroup? group = null;

            if(org != null)
            {
                group = org?.Groups.Find(g => g.Name == SelectedGroupName);
            }

            var hashPassword = BCrypt.Net.BCrypt.HashPassword(Password);

            var newUser = new User(login: Login, fullname: Fullname, hashPassword: hashPassword, group, org);

            var success = await _userStore.AddUserAsync(newUser);
            
            if(!success)
            {
                ModelState.AddModelError("", "������������ � ����� ������� ��� ����������");
                return Page();
            }

            return RedirectToPage("/Index");
        }
    }
}
