﻿using CodePlatform.Models;

namespace CodePlatform.Classes
{
    public class StaticData
    {
        public static List<Organization> Organizations = new List<Organization>
        {
            new Organization("Организация 1", new List<ClassGroup>
            {
                new ClassGroup("Группа 1", "Дизайн", 1)
            }),
            new Organization("Организация 2", new List<ClassGroup>
            {
                new ClassGroup("Группа 2", "Математика", 2)
            }),
            new Organization("Организация 3", new List<ClassGroup>
            {
                new ClassGroup("Группа 3", "Информатика", 3)
            })
        };
    }
}
