﻿using CodePlatform.Models;

namespace CodePlatform.Interfaces
{
    public interface IUserFileStore
    {
        Task<List<User>> GetAllUserAsync();
        Task<User?> GetUserByLoginAsync(string login);
        Task<bool> AddUserAsync(User user);
    }
}
