﻿using BCrypt.Net;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace CodePlatform.Models
{
    public class User
    {
        public string Login { get; set; }
        public string Fullname { get; set; }
        public string HashedPassword { get; set; }
        public ClassGroup ClassGroup { get; set; }
        public Organization Organization {get;set; }


        public User (string login, string fullname, string hashPassword, ClassGroup group, Organization organization)
        {

            Login = login;
            HashedPassword = hashPassword;
            Fullname = fullname;
            ClassGroup = group;
            Organization = organization;
        }

        public static string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }
    }
}
