﻿namespace CodePlatform.Models
{
    public class Organization
    {
        public string Name { get; set; }
        public List<ClassGroup> Groups { get; set; } = new();

        public Organization() { }
        public Organization(string name, List<ClassGroup> groups)
        {
            Name = name;
            this.Groups = groups;
        }
        public override string ToString()
        {
            return Name;
        }
    }
}
